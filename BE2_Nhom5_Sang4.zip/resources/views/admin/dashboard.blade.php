@extends('admin_layout')
@section('admin_content')
<h3>Chào mừng đến với trang Admin</h3>
@endsection

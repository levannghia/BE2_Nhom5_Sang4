<div class="sidebar_widget bottom ">
    <div class="banner_img">
        <a href="#"><img src="{{ asset('img\banner\giao-hang.jpg') }}" alt=""></a>
    </div>
</div>
<br>
<div class="sidebar_widget bottom ">
    <div class="banner_img">
        <a href="#"><img src="{{ asset('img\banner\banner12a.jpg') }}" alt=""></a>
    </div>
</div>
<br>
<div class="sidebar_widget bottom ">
    <div class="banner_img">
        <a href="#"><img src="{{ asset('img\banner\tetdoanngo.jpg') }}" alt=""></a>
    </div>
</div>